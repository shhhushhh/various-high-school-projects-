#pragma once

#include "listnode.h"

void mergeSort(ListNode*& front);
void quickSort(ListNode*& front);
