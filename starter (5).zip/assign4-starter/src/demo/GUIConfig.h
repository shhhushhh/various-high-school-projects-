
MENU_OPTION("Mapping Earthquakes", makeEarthquakeGUI)
MENU_OPTION("Child Mortality", makeChildMortalityGUI)
MENU_OPTION("Women's 800m", makeWomens800mGUI)

WINDOW_TITLE("Priority Queue Demos")
