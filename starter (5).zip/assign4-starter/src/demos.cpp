#include "testing/SimpleTest.h"

/* 
 * Do not modify the code beyond this line! There are no
 * unit tests for this problem. You should do all testing
 * via the interactive demo. 
 */

void runDemos();

PROVIDED_TEST("Interactive Demos using Top-K to do cool data visualization tasks!") {
    runDemos();
}